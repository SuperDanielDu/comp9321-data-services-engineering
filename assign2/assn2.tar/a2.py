'''
COMP9321 2019 Term 1 Assignment Two Code Template
Student Name:
Student ID:
'''
import sqlite3


def create_db(db_file):
    '''
    uase this function to create a db, don't change the name of this function.
    db_file: Your database's name.
    '''
    pass 

'''
Put your API code below. No certain requriement about the function name as long as it works.
'''
